import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private Map<String, Task> tasks = new HashMap<>();

    public void addTask(Task task) {
        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task with this ID already exists");
        }
        tasks.put(task.getTaskId(), task);
    }

    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }

    public void deleteTask(String taskId) {
        tasks.remove(taskId);
    }

    public void updateTaskName(String taskId, String newName) {
        Task task = getTask(taskId);
        task.setName(newName);
    }

    public void updateTaskDescription(String taskId, String newDescription) {
        Task task = getTask(taskId);
        task.setDescription(newDescription);
    }
}
