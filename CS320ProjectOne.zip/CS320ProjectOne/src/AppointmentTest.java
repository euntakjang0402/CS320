import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

public class AppointmentTest {

    @Test
    public void testValidAppointmentCreation() {
        Appointment appointment = new Appointment("A123456789", new Date(System.currentTimeMillis() + 86400000), "This is a test appointment description");
        assertNotNull(appointment);
    }

    @Test
    public void testInvalidAppointmentId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A1234567890", new Date(System.currentTimeMillis() + 86400000), "This is a test appointment description");
        });
    }

    @Test
    public void testPastAppointmentDate() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A123456789", new Date(System.currentTimeMillis() - 86400000), "This is a test appointment description");
        });
    }

    @Test
    public void testInvalidAppointmentDescription() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A123456789", new Date(System.currentTimeMillis() + 86400000), "This appointment description is definitely way too long to fit the requirements provided in the assignment");
        });
    }
}
