import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    @Test
    public void testValidContactCreation() {
        Contact contact = new Contact("C123456789", "John", "Doe", "1234567890", "123 Street");
        assertNotNull(contact);
    }

    @Test
    public void testInvalidContactId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("C1234567890", "John", "Doe", "1234567890", "123 Street");
        });
    }

    @Test
    public void testInvalidFirstName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("C123456789", "Johnathan", "Doe", "1234567890", "123 Street");
        });
    }

    @Test
    public void testInvalidLastName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("C123456789", "John", "Doenathan", "1234567890", "123 Street");
        });
    }

    @Test
    public void testInvalidPhone() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("C123456789", "John", "Doe", "12345678901", "123 Street");
        });
    }

    @Test
    public void testInvalidAddress() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("C123456789", "John", "Doe", "1234567890", "123 Street, City, Country");
        });
    }
}
