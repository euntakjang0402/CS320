import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    private ContactService contactService;

    @BeforeEach
    public void setup() {
        contactService = new ContactService();
    }

    @Test
    public void testAddContact() {
        Contact contact = new Contact("C123456789", "John", "Doe", "1234567890", "123 Street");
        contactService.addContact(contact);
        assertEquals(contact, contactService.getContact("C123456789"));
    }

    @Test
    public void testAddDuplicateContact() {
        Contact contact1 = new Contact("C123456789", "John", "Doe", "1234567890", "123 Street");
        Contact contact2 = new Contact("C123456789", "Jane", "Doe", "0987654321", "456 Avenue");
        contactService.addContact(contact1);
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.addContact(contact2);
        });
    }

    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("C123456789", "John", "Doe", "1234567890", "123 Street");
        contactService.addContact(contact);
        contactService.deleteContact("C123456789");
        assertNull(contactService.getContact("C123456789"));
    }

    @Test
    public void testUpdateContactFirstName() {
        Contact contact = new Contact("C123456789", "John", "Doe", "1234567890", "123 Street");
        contactService.addContact(contact);
        contactService.updateContactFirstName("C123456789", "Jane");
        assertEquals("Jane", contactService.getContact("C123456789").getFirstName());
    }

    @Test
    public void testUpdateContactLastName() {
        Contact contact = new Contact("C123456789", "John", "Doe", "1234567890", "123 Street");
        contactService.addContact(contact);
        contactService.updateContactLastName("C123456789", "Smith");
        assertEquals("Smith", contactService.getContact("C123456789").getLastName());
    }

    @Test
    public void testUpdateContactPhone() {
        Contact contact = new Contact("C123456789", "John", "Doe", "1234567890", "123 Street");
        contactService.addContact(contact);
        contactService.updateContactPhone("C123456789", "0987654321");
        assertEquals("0987654321", contactService.getContact("C123456789").getPhone());
    }

    @Test
    public void testUpdateContactAddress() {
        Contact contact = new Contact("C123456789", "John", "Doe", "1234567890", "123 Street");
        contactService.addContact(contact);
        contactService.updateContactAddress("C123456789", "456 Avenue");
        assertEquals("456 Avenue", contactService.getContact("C123456789").getAddress());
    }
}
