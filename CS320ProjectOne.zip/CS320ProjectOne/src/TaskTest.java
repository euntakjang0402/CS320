import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    @Test
    public void testValidTaskCreation() {
        Task task = new Task("T123456789", "TestTask", "This is a test task description");
        assertNotNull(task);
    }

    @Test
    public void testInvalidTaskId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("T1234567890", "TestTask", "This is a test task description");
        });
    }

    @Test
    public void testInvalidTaskName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("T123456789", "ThisTaskNameIsTooLongForSure", "This is a test task description");
        });
    }

    @Test
    public void testInvalidTaskDescription() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("T123456789", "TestTask", "This task description is definitely way too long to fit the requirements provided in the assignment");
        });
    }
}
