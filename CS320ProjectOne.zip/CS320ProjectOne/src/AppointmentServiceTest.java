import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

public class AppointmentServiceTest {

    private AppointmentService appointmentService;

    @BeforeEach
    public void setup() {
        appointmentService = new AppointmentService();
    }

    @Test
    public void testAddAppointment() {
        Appointment appointment = new Appointment("A123456789", new Date(System.currentTimeMillis() + 86400000), "This is a test appointment description");
        appointmentService.addAppointment(appointment);
        assertEquals(appointment, appointmentService.getAppointment("A123456789"));
    }

    @Test
    public void testAddDuplicateAppointment() {
        Appointment appointment1 = new Appointment("A123456789", new Date(System.currentTimeMillis() + 86400000), "This is the first test appointment description");
        Appointment appointment2 = new Appointment("A123456789", new Date(System.currentTimeMillis() + 172800000), "This is the second test appointment description");
        appointmentService.addAppointment(appointment1);
        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.addAppointment(appointment2);
        });
    }

    @Test
    public void testDeleteAppointment() {
        Appointment appointment = new Appointment("A123456789", new Date(System.currentTimeMillis() + 86400000), "This is a test appointment description");
        appointmentService.addAppointment(appointment);
        appointmentService.deleteAppointment("A123456789");
        assertNull(appointmentService.getAppointment("A123456789"));
    }

    @Test
    public void testUpdateAppointmentDate() {
        Appointment appointment = new Appointment("A123456789", new Date(System.currentTimeMillis() + 86400000), "This is a test appointment description");
        appointmentService.addAppointment(appointment);
        appointmentService.updateAppointmentDate("A123456789", new Date(System.currentTimeMillis() + 172800000));
        assertTrue(appointmentService.getAppointment("A123456789").getAppointmentDate().getTime() > System.currentTimeMillis());
    }

    @Test
    public void testUpdateAppointmentDescription() {
        Appointment appointment = new Appointment("A123456789", new Date(System.currentTimeMillis() + 86400000), "This is a test appointment description");
        appointmentService.addAppointment(appointment);
        appointmentService.updateAppointmentDescription("A123456789", "Updated appointment description");
        assertEquals("Updated appointment description", appointmentService.getAppointment("A123456789").getDescription());
    }
}
