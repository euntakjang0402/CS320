import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {

    private TaskService taskService;

    @BeforeEach
    public void setup() {
        taskService = new TaskService();
    }

    @Test
    public void testAddTask() {
        Task task = new Task("T123456789", "TestTask", "This is a test task description");
        taskService.addTask(task);
        assertEquals(task, taskService.getTask("T123456789"));
    }

    @Test
    public void testAddDuplicateTask() {
        Task task1 = new Task("T123456789", "TestTask1", "This is the first test task description");
        Task task2 = new Task("T123456789", "TestTask2", "This is the second test task description");
        taskService.addTask(task1);
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.addTask(task2);
        });
    }

    @Test
    public void testDeleteTask() {
        Task task = new Task("T123456789", "TestTask", "This is a test task description");
        taskService.addTask(task);
        taskService.deleteTask("T123456789");
        assertNull(taskService.getTask("T123456789"));
    }

    @Test
    public void testUpdateTaskName() {
        Task task = new Task("T123456789", "TestTask", "This is a test task description");
        taskService.addTask(task);
        taskService.updateTaskName("T123456789", "UpdatedTask");
        assertEquals("UpdatedTask", taskService.getTask("T123456789").getName());
    }

    @Test
    public void testUpdateTaskDescription() {
        Task task = new Task("T123456789", "TestTask", "This is a test task description");
        taskService.addTask(task);
        taskService.updateTaskDescription("T123456789", "Updated task description");
        assertEquals("Updated task description", taskService.getTask("T123456789").getDescription());
    }
}
