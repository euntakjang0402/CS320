import java.util.Date; 
import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    private Map<String, Appointment> appointments = new HashMap<>();

    public void addAppointment(Appointment appointment) {
        if (appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Appointment with this ID already exists");
        }
        appointments.put(appointment.getAppointmentId(), appointment);
    }

    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }

    public void deleteAppointment(String appointmentId) {
        appointments.remove(appointmentId);
    }

    public void updateAppointmentDate(String appointmentId, Date newDate) {
        Appointment appointment = getAppointment(appointmentId);
        if (appointment != null) {
            appointment.setAppointmentDate(newDate);
        } else {
            throw new IllegalArgumentException("Appointment with this ID doesn't exist");
        }
    }

    public void updateAppointmentDescription(String appointmentId, String newDescription) {
        Appointment appointment = getAppointment(appointmentId);
        if (appointment != null) {
            appointment.setDescription(newDescription);
        } else {
            throw new IllegalArgumentException("Appointment with this ID doesn't exist");
        }
    }
}
